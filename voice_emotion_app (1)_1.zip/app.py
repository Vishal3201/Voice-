import streamlit as st
import whisper
import librosa
import numpy as np
import pandas as pd
import plotly.express as px
import soundfile as sf
from transformers import pipeline
import os

@st.cache_resource
def load_models():
    whisper_model = whisper.load_model("base")
    emotion_model = pipeline(
        "text-classification",
        model="j-hartmann/emotion-english-distilroberta-base",
        return_all_scores=True
    )
    sentiment_model = pipeline("sentiment-analysis")
    return whisper_model, emotion_model, sentiment_model

whisper_model, emotion_model, sentiment_model = load_models()

st.set_page_config(page_title="Voice Emotion Dashboard", layout="wide")
st.title("🎙️ Voice Emotion & Sentiment Analysis Dashboard")

audio_file = st.file_uploader("Upload Audio File", type=["wav", "mp3"])

if audio_file:
    st.audio(audio_file)

    with open("input_audio.wav", "wb") as f:
        f.write(audio_file.read())

    y, sr = librosa.load("input_audio.wav", sr=16000)
    chunk_duration = 10
    samples_per_chunk = chunk_duration * sr

    results = []

    for i in range(0, len(y), samples_per_chunk):
        chunk = y[i:i + samples_per_chunk]
        if len(chunk) < samples_per_chunk:
            continue

        start_time = i // sr
        chunk_file = f"chunk_{i}.wav"
        sf.write(chunk_file, chunk, sr)

        text = whisper_model.transcribe(chunk_file)["text"].strip()

        if text:
            emotions = emotion_model(text)[0]
            dominant_emotion = max(emotions, key=lambda x: x["score"])["label"]
            sentiment = sentiment_model(text)[0]["label"]

            results.append({
                "Timestamp": f"{start_time//60}:{start_time%60:02d}",
                "Emotion": dominant_emotion,
                "Sentiment": sentiment,
                "Text": text
            })

        os.remove(chunk_file)

    df = pd.DataFrame(results)

    st.subheader("📍 Emotion Changes")
    st.dataframe(df)

    fig1 = px.scatter(df, x=df.index, y="Emotion", color="Emotion")
    st.plotly_chart(fig1)

    fig2 = px.pie(df, names="Emotion")
    st.plotly_chart(fig2)

    st.success("Analysis Complete")
